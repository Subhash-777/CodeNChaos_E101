import { AuthPage } from "@/components/auth-page"

export default function Home() {
  return <AuthPage />
}
